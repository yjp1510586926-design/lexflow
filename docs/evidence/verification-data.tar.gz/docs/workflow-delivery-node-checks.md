# 工作流有限投递与只读恢复探针：Node 验证

2026-10-09 当前 Node 实现已通过 64 项定向检查，失败、取消和跳过均为 0。检查使用本地独立 AI 数据库、独立 RabbitMQ vhost 和合成模型，没有调用真实服务商。源码、编译产物和日志 SHA 见 [机器证据](evidence/workflow-delivery-node-checks.json)，完整输出见 [检查日志](evidence/workflow-delivery-node-final.log)。这份证据不代表 Java 死信登记、人工恢复及浏览器业务闭环已经完成；这些由单独验收证明。

合同、文书生成和案件分析沿用 10/60/300 秒、最多三次的投递延迟。自动投递只改变恢复 header，原始 UTF8 正文、次数和版本保持不变。领取后的相邻 RUNNING 版本可以重投；合同和案件分析也接受人工批准后与事件相等的 RUNNING 版本，但始终核对 tenant、task、resourceVersion 和 attempt。生成核对的是 source documentVersion。成功回调 503 不改发失败结果；Busy 副本只 ACK；付费日志的不确定状态直接进入 UNCERTAIN 死信；已记账的 FAILED 只重新交付失败结果。

真实 RabbitMQ 检查分别观察了三类 10 秒 TTL 回到原队列，并检查 60/300 秒配置、次数耗尽及 UNCERTAIN 死信。真实 AI SQL 检查在 18 个独立 Node 子进程中验证了三类工作流的 checkpoint 写故障、成功回调 503 和已开始的供应商 429：已成功步骤复用缓存，FAILED 步骤不再次请求供应商。中间缓存状态同时经过独立恢复探针验证。

## 内部协议与拒绝恢复条件

`POST /internal/v1/workflow-recovery/eligibility` 要求 `X-Internal-Secret`，正文严格为 `{type, taskId, executionProtocol: 2, input, verifiedEvidence?}`。`input` 是领域现有输入去除 `apiKey`，不允许其他凭据字段。只有合同可提供 `verifiedEvidence`，且 Java 必须先实时验证这些引用。此路径单独允许最多 8 MiB JSON，普通路径仍限制 256 KiB，旧索引探针保持原协议。

探针只取得原工作流的非阻塞命名锁、读取有界日志/当前分区快照及必要成功缓存、释放锁。它不初始化表、不调用模型或检索、不写 lease、journal 或 checkpoint。使用图本身的 identity 和 operation hash 函数，并用实际前置节点结果核对每个步骤的摘要；合同补材仍使用原 thread 和 `contract-round-n` 分区。

以下情况会禁止恢复：

- 执行协议不是 2，或身份、固定输入、分区、操作键、依赖摘要不符。
- 任一相关轮次有 STARTED、FAILED 或未知状态；费用确认不能覆盖这些状态。
- 合同缓存了非空 RAG 引用，但没有 Java 实时验证过的同编号、同文字依据。领域尚无报告时，不能用新的检索请求补足证明。
- 合同或案件分析已有 `decisionId`，但当前轮次 checkpoint 或报告缺失。
- 原线程繁忙、数据超限或不能解码、数据库不可用、锁释放失败，或其他无法证明安全的情况。

Java 仍须在人工动作事务中验证当前 DEAD ledger、登记状态版本、任务私有访问、创建人实时权限、固定来源、当前模型配置和依据活性，并再次调用探针。Node 的 SAFE 只证明现有计算记录可复用，不代替这些领域授权。

## 检查资源清理

每个真实 SQL fixture 都使用随机 task，并仅删除自己的 thread。最后只读检查确认专用租户 `910000302`、`910000303` 在 `workflow_thread`、`workflow_checkpoint`、`workflow_checkpoint_write`、`workflow_operation` 四表均为 0。独立 `lexflow-workflow-delivery-<UUID>` vhost 删除后通过 404 检查，最终没有该前缀遗留 vhost。测试 HTTP 服务、RabbitMQ 连接和子进程已退出；基础容器继续保留。详见 [清理证据](evidence/workflow-delivery-node-cleanup.json)。

跨进程注入脚本位于 `ai-service/test/support/workflow-recovery-child.cjs`，参数为 `TYPE MODE TENANT TASK COUNTER`，MODE 为 `checkpoint`、`callback`、`paid429`、`resume` 或 `callback-resume`。该脚本使用固定合成输入和模拟 Java 回调；实际 HTTP 闭环应读取真实领域输入，保持相同任务身份，复用其注入位置即可，不能把模拟回调结果当作真实 Java 验收。
