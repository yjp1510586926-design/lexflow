# 首次管理员初始化

仅在全新、空的 LexFlow 开发数据库上使用；已有律所数据会拒绝初始化，不覆盖用户和密码。先启动项目 Docker 基础设施并完成 `mvn verify` 构建。

在本机终端设置三个环境变量，再以 `bootstrap` profile 启动 Java：

```sh
export LEXFLOW_TENANT_NAME='我的律所'
export LEXFLOW_ADMIN_USERNAME='admin'
# zsh：交互输入，不把密码写进命令历史或文档
read -s 'LEXFLOW_ADMIN_PASSWORD?初始密码（至少12字符）: '
export LEXFLOW_ADMIN_PASSWORD
java -jar api-core/target/api-core-0.1.0-SNAPSHOT.jar --spring.profiles.active=bootstrap
```

密码的 UTF-8 编码不得超过 72 字节。启动日志只显示新建律所 ID，不输出密码。记下律所 ID，登录时使用该 ID、用户名和密码。初始化失败会回滚整个创建事务。

初始化成功后可停止应用，执行 `unset LEXFLOW_ADMIN_PASSWORD`，以后用普通启动命令，不再携带 bootstrap profile。重复初始化会让该次启动失败，以免误覆盖已有数据。

初始角色：律所管理员、律师、只读成员。律师拥有业务操作权限，但仍须是目标案件的成员；只读成员不能写入案件或文件。

管理接口：

- `GET /api/v1/organization/users`：本律所账号列表。
- `POST /api/v1/organization/users`：新建账号，字段 username、password、name、role。
- `PATCH /api/v1/organization/users/{id}`：设置租户成员 status（ACTIVE/DISABLED）与 role（TENANT_ADMIN/LAWYER/READER）。

这些接口必须使用已登录律所管理员会话，写入附带 CSRF token。现有同名账号不会被静默加入另一个律所。操作不会修改其他律所成员关系；最后一名有效管理员不能被禁用或降级。
