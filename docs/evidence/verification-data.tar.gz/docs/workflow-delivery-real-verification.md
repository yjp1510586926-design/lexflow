# 三类工作流投递恢复：实际服务联合验收

2026-10-09 在新的随机业务数据库、独立 AI 数据库、RabbitMQ vhost、私有 bucket 和 Spring Session namespace 中完成 37 个独立检查条目。Java HTTP、RabbitMQ 消费、工作流 SQL 与页面使用实际服务。只替换模型供应商调用，并用仅限本轮任务的本地 HTTP 代理返回真实 503；没有真实供应商、embedding 请求或费用。

本轮共创建 7 个任务：1 个真实 TXT 解析、合同审查/文书生成/案件分析各 1 个，以及未开始模型的合同、留下 STARTED 日志的生成和产生 FAILED 日志的生成。工作流共 9 条操作记录，合成模型总调用数为 9。这里的“37”是去重后的场景检查条目，不是新增测试用例数，也不代表整个项目已经完成。

## 实际闭环

三个新任务从公开 HTTP 接口创建，由真实 outbox 发布和 MQ 消费；合同与案件分析各调用 2 个合成模型步骤，生成调用 1 个。首次成功结果回调收到本地 HTTP 503。各队列的真实 10 秒 TTL 重投再次交付相同执行，模型调用数仍为 2 / 1 / 2。

随后使用绑定原 outbox 的自有事件副本和 retry=3 进入死信，各任务登记 WAITING_HUMAN(DELIVERY)。律师在真实页面打开处理记录，费用未勾选时按钮禁用，勾选后各提交一次恢复；SQL 确认每个恢复 UUID 只有一个 intent 和对应恢复事件。

| 类型 | 第一次人工恢复后的业务结果 | 后续实际检查 |
| --- | --- | --- |
| 合同审查 | attempt=1，WAITING_HUMAN，sv=6，报告待复核 | 页面人工确认到 RUNNING sv=7；再次回调 503/死信登记到 sv=8 后，报告、decision 和 round 保留。页面再次恢复到 attempt=2、sv=9，最后 SUCCEEDED sv=11；合成模型仍只有原来的 2 次。 |
| AI 文书生成 | attempt=1，SUCCEEDED，sv=6 | 生成独立 AI_DRAFT v2 / PENDING_REVIEW，人工当前版本仍是 v1、文书仍为 DRAFT；旧次数回调不能追加或覆盖结果。 |
| 案件分析 | attempt=1，WAITING_HUMAN，sv=6，材料引用及报告待复核 | 页面填写复核意见并确认，最终 SUCCEEDED sv=8；合成模型仍只有原来的 2 次。 |

恢复 UUID 的同参数重发返回 202，未增加 outbox；改变费用绑定返回 409。旧次数的普通队列和 DLQ 副本没有重启新次数。先前恢复 intent 重发也不能重新启动合同后续死信。

## 拒绝与故障检查

- 三类费用未确认的后端请求均返回 400，attempt、sv 和 outbox 数不变。DELIVERY 不能从合同 approve/supplement 或案件 approve 绕过。
- 同案件普通同事读取他人的恢复详情返回 403。修改本轮生成基准正文后，恢复资格关闭、动作返回 409；原文随后恢复。真正撤销创建人的案件成员资格后，管理员也不能绕过，返回 403；成员随后恢复。
- 只在本轮 schema 临时重命名 `audit_log`，让实际合同死信登记审计失败：任务保持 RUNNING sv=2，ledger 为 0，消息仍在自有 DLQ；仅合同 collector 暂停，其他自有 collector 保持监听。还原表后，同一消息重新投递并成功登记 DEAD / WAITING_HUMAN sv=3。
- 一个合同在非付费原文下载阶段持续收到 503，进入 DEAD 时模型调用数为 0。真实页面明确勾选恢复费用后，首次执行 2 个模型步骤并产生待复核报告。
- 在一个生成任务的操作日志为 STARTED、合成模型调用已开始时，确认 PID 后只终止本轮 Node。重启同一冻结代码后，原 MQ 消息直接进入 UNCERTAIN DLQ，retry=0；后端费用确认也返回 409，日志仍为 STARTED，调用数仍为 1。
- 另一个生成的合成模型抛出 429，操作日志为 FAILED。失败结果回调收到 503，重投仍复用原失败；人工恢复返回 409，日志保持 FAILED，调用数仍为 1。实际页面中 STARTED/FAILED 两种情况均禁用恢复按钮且不提供费用复选框。

## 证据、限制与清理

机器记录见 [联合检查](evidence/workflow-delivery-real-checks.json) 和 [精确清理](evidence/workflow-delivery-real-cleanup.json)。记录含公开 HTTP 状态、恢复 intent、任务/ledger/操作快照、模型计数、原始安全日志、9 张已查看的截图，以及 Java jar、42 个 Node 编译文件和相关前端源码的 SHA-256。截图展示 [合同完成](evidence/workflow-delivery-real-contract-complete.png)、[生成待复核版本](evidence/workflow-delivery-real-generation-complete.png)、[案件分析完成](evidence/workflow-delivery-real-analysis-complete.png)、[不确定步骤禁恢复](evidence/workflow-delivery-real-task-6-blocked.png) 和 [失败步骤禁恢复](evidence/workflow-delivery-real-task-7-blocked.png)。

Java 运行产物是已验证的 V24 jar，未包含之后的审计、向量回收、导出生命周期改动。旧 jar 的新安装 LAWYER 角色缺少 `ai:generate` 在本轮再次观察到；只在自有测试角色临时授予该权限，最新源码修复由另一专项验证，不能用本轮替代该验证。

实际等待了三类 10 秒 TTL；60/300 秒只检查队列参数，最后死信用自有副本的 retry=3 触发，并未完整等待全部延迟。副本取自 MySQL JSON，因此本轮只证明固定事件身份、attempt 和 sv，不声称与最初 broker 消息逐字节相同；逐字节 UTF-8 的独立 Node MQ 检查见 [Node 专项](workflow-delivery-node-checks.md)。本轮材料与模型输出均为合成数据，不证明真实法律答复质量、供应商耗时或费用。

此前临时目录和进程已消失，但原随机 UUID 对应的两数据库、账号、vhost 和两个私有对象仍在 Docker 卷中。本轮先用实际 SHOW GRANTS 证明账号仅绑定原自有库，核对 bucket 对象与原 file_version，再与本轮资源分组精确清理。两组各自剩余 schema/账号均为 0，bucket/vhost 为 404，三个对象逐个 HEAD=404；本轮 4 个 Redis namespace key 已删除，原 UUID 的两种精确匹配均为 0。浏览器已关闭；末尾退出登录的驱动没有找到弹窗，未宣称成功退出，而是删除本轮 Redis namespace 使会话失效。自有 Java、Node、Vite 均停止，8097/8098/3017/5188 无监听，临时凭据文件为 0。原 6 个开发容器身份不变且全部健康；共享登录 IP 限流计数未删除。
