# 合同、文书生成及案件分析的有限投递重试与死信恢复设计草稿

状态：只读设计，尚未实现。依据 2026-10-09 当前源码；不覆盖已冻结运行时和正在进行的合同实际验收。本文不代表新增功能已经通过测试。现有解析/索引入口、V20、10/60/300 秒策略和工作流日志语义保持兼容；实施仅限后续开发环境，不修改生产发布策略。

## 现状与接入前提

| 位置 | 当前行为 | 必要变化 |
| --- | --- | --- |
| ai-service/src/transport/task-delivery.service.ts | 队列白名单仅解析/索引；transientDeliveryFailure 识别连接错误、HTTP 429/5xx、数据库锁超时及 WorkflowBusyError；defer 确认持久副本后 ACK，失败 nack(false,false) | 增加三个工作队列，复用相同有界延迟和确认规则，不把业务 attempt 当投递计数 |
| 三个工作流消费者 | 运行时错误大多转业务 FAILED/UNCERTAIN；回调失败直接 DLQ，没有有限 TTL；合同已支持任意当前轮 Q→R 相邻版本 | 按阶段处理瞬时基础设施错误，成功回调失败不能转失败回调；保留 journal 错误优先级 |
| RabbitMqConfig | 三类型工作队列和 DLQ 已存在，仅解析/索引有 6 个 retry 队列 | 新增 9 个 retry 队列，主队列/DLQ 的现有参数不变 |
| TaskDeadLetterCollector | 仅解析/索引两个监听；大小/严格 JSON/原 outbox 绑定/持久隔离及数据库失败暂停已有实现 | 新增三个独立监听，扩充类型识别，沿用事务成功后 ACK 的语义 |
| TaskDeliveryRecoveryBiz | TYPES/queue/route/requireSource 仅解析/索引；登记只比较 attempt；人工恢复 attempt+1、sv+1→QUEUED | 新增类型适配器；增加原事件状态版本和当前登记状态版本保护；不能仅扩大 TYPES |
| TaskContextBiz / AsyncTaskMapper.getTaskContext | JOIN file_version；合同和案件分析取得原文件/首份文件，不能校验全份材料；没有生成类型 | 生成 resourceVersionId 指 document_version，不能加入现有 file_version JOIN；生成恢复走领域输入适配器 |
| IndexRecoveryEligibilityClient / AI SQL probe | 索引专用无模型探针，SAFE/BUSY/UNCERTAIN/FAILED/INPUT_CHANGED/UNAVAILABLE，5 秒全响应超时、1024 字节结果、严格结构、无 Key | 保持原端点/响应兼容；新增三工作流探针并复用这些边界，不能复制索引批次哈希算法 |
| TasksPage / TaskDeliveryRecoveryPanel | 处理记录按钮仅解析/索引；费用勾选仅索引 | 增加三类型；所有付费类型人工恢复要求显式费用确认，UNCERTAIN/FAILED/无法验真均禁恢复 |

人工恢复一旦接入，原本只有 Q1→R2 的生成和案件分析也会出现 Q4→R5 等状态，必须同步改相邻领取后的重投。生成消费者先请求 generationInput(event)，所以还要修改 DocumentGenerationService.execution(firstReplay)；仅修改消费者不够。

合同保留本轮已修好的严格 taskId/resourceVersionId/attempt 匹配。案件消费者还应比较返回 taskId 与事件 taskId，以及新增 context.resourceVersionId 与原事件源版本；完整 sources 仍由领域服务复核。生成事件增加并验证 resourceVersionId，并与 generationInput.sourceVersionId 严格相等；这里比较的是基准 document_version。三者都在取得配置/执行前验证身份，不能把新 attempt 当作更新材料的授权。

## 状态与固定输入

自动 TTL：正文保持原始字节，eventId、tenant/task/source、case、attempt、stateVersion 不变；只增加 x-lexflow-delivery-retry。最多三次，10/60/300 秒，之后 DLQ。原任务 QUEUED→RUNNING 的领取仅增加 sv 一次。

新类型 DLQ 登记应在锁定 async_task 的同一事务中完成：
1. 严格验证 queue/type、事件结构、源版本、同 tenant/task/attempt，逐字段匹配原 outbox_event。
2. 只接受当前事件：event.sv==task.sv，或 task.status==RUNNING 且 task.sv==event.sv+1。已绑定但过期/终态的事件 ACK 丢弃，不建立新 ledger，不隔离为伪造事件。
3. QUEUED/RUNNING→WAITING_HUMAN，sv+1；ledger 记录当前 attempt 和登记后的 sv；kind/retry 不降级。
4. 合同/案件分析 waiting_reason 改为 DELIVERY，保留已有报告、原合同、条款、轮次、补材快照和人工 decision；UNCERTAIN 分类则使用 UNCERTAIN。DELIVERY 不允许 approve/supplement。生成通过 ledger 的当前 sv 判别投递待处理，不靠可变错误文案。
5. 旧绑定事件不得凭“同 attempt”中断下一补材轮或人工确认后的执行。

建议新迁移（编号由 root 根据届时最新迁移选择，不能重写 V20/V21/V22/V23）：
- task_delivery_recovery 增加 nullable registered_state_version；三新类型必须非空且等于当前 task.sv，解析/索引历史记录保留兼容。
- contract_review / case_analysis 的 waiting_reason CHECK 增加 DELIVERY，明确命名并替换约束。
- 三领域表增加 execution_protocol，历史默认 1，新提交显式写 2。历史协议无法证明付费调用已记账，统一人工死信恢复拒绝，提示取消核对后新建；不得把“AI SQL 没有行”当作历史任务从未付费。不得为旧记录批量改为 2。

人工恢复事务：
- 任务私有访问和领域权限校验→锁任务/当前 ledger→同 UUID 幂等意图核对→当前源/创建人/配置复核→AI SAFE 探针→付费类型费用确认→CAS。
- WAITING_HUMAN(DELIVERY)+当前 DEAD ledger→QUEUED；attempt+1，sv+1，清理任务执行错误和本次运行时间；合同/分析清 DELIVERY，保留报告/decision/round，生成保留 document/sourceVersion/resultVersion 字段。
- outbox、新恢复意图、ledger RESOLVED、审计必须同事务提交。任何写入/序列化失败全部回滚，不能吞异常后返回成功。
- 同 UUID 网络重试返回当前记录，不重复递增、不重复 outbox；UUID 不能用于其他 actor/task/sv/confirmModelCosts。新一轮死信不能被旧恢复 UUID 重启。
- 旧 attempt 的消息、回调、死信均不能更新新 attempt。
- 所有图继续使用原 lf:tenant:task 线程；合同继续当前 contract-round-n 命名空间和原轮次 operation_key。attempt/sv 不加入计算身份，不创建新 namespace，不删除或重置日志。
- 新 QUEUED 事件领取一次增加 sv；三个消费者均支持同源同次数的相邻 RUNNING 重投。生成 Java input 的旧事件允许范围同步为此一次领取，保留源/权限/CAS。
- 现有领域 recover(QUEUED/RUNNING) 保持“同次继续”的已有语义；DELIVERY 状态只能经统一幂等人工入口恢复，不能从旧按钮绕过费用和日志检查。

## 错误按阶段分流

| 阶段/错误 | 行为 |
| --- | --- |
| 非法/未绑定事件 | 入 DLQ/持久隔离，不读取配置或调用模型 |
| 当前任务已终态、旧 attempt/旧轮次、来源身份不一致 | ACK 丢弃，不回报结果 |
| 获取上下文/领取/非付费原文下载的连接错误、429/5xx、数据库锁冲突 | 有限 TTL，同一 invocation，不增加 attempt，不更换源 |
| 当前原件/材料/角色已撤销、配置冲突、格式无效 | 不自动重试；永久 DLQ 或现有明确业务 FAILED，记录/展示不能恢复 |
| 当前同线程另一执行者持锁 | 最小实现保留现有三消费者 WorkflowBusyError ACK 副本行为；主执行消息仍未确认且有原线程锁，不把此副本当任务失败登记。索引既有 Busy TTL 不改 |
| runOnce 抛 WorkflowOperationUncertainError | 直接 UNCERTAIN DLQ；不调用失败回调覆盖，不做 TTL，不清 STARTED |
| runOnce 抛 WorkflowOperationFailedError | 明确业务 FAILED，既有回调失败可有限重投以交付该失败，但不能再发模型请求；人工恢复探针必须拒绝 FAILED |
| 已保存 SUCCEEDED 操作后的 checkpoint/Java 成功回调瞬时故障 | 有限 TTL，复用原缓存；不能改发 FAILED/UNCERTAIN 覆盖成功结果 |
| 第三次瞬时重试仍失败 | 原字节进入同类 DLQ，收集器登记一次 |
| 延迟/DLQ 副本确认失败、被退回或超时 | 不 ACK 未确认副本；现有 nack(false,false) 使原消息进入原 DLQ；付费类型没有可信分类 header 时保守 UNCERTAIN |

runOnce 当前已经把 operation/action 内部失败转换为 WorkflowOperationFailedError，写失败时转 UNCERTAIN。因此供应商 429/5xx 一旦属于已记录付费步骤，不能按裸 HTTP 瞬时错误重新收费。分类必须先判断 journal 错误，再判断 transientDeliveryFailure；不要捕获后生成新 key。

生成消费者目前将全部 HTTP 401/403/404/409 直接 ACK；接入时不能把仍处于当前执行版本的权限/源/模型冲突吞成“已处理”。在不能从输入响应确认终态/旧版本时，将这些内部永久错误送 PERMANENT DLQ，由收集器依据权威 task/outbox 判断：真正过期或终态只 ACK，当前事件登记不可恢复原因。这样无需为生成任务错误套用文件 context。

三个图的 authorized() 包装和合同 parseDocument 包装目前会丢失 HTTP 瞬时错误信息。应只在付费 journal 之外保留一个无正文/Key的可识别基础设施瞬时错误；永久授权错误仍为通用业务错误。runOnce 内的错误规则不变。授权调用发生在 STARTED 之后即使尚未请求供应商也按现有 FAILED/UNCERTAIN 规则停止，不能假定可以安全重试。执行恢复仍在模型前后及发布前检查实时授权。

不要为接入 TTL 改为 callback(FAILED) 后再投递同一成功结果；claim 失败时也不能用旧 active 版本发布结果。成功/失败/不确定回调均使用已领取的当前 attempt/sv。

## 当前权限与来源适配器

统一 Biz 始终先 TaskService.get：普通用户只能访问自己任务，管理员仍需当前案件读取权限；再要求 task:cancel 和领域修改权限。内部共享 secret 不代替业务创建人的实时授权。

| 类型 | 固定身份与当前授权 |
| --- | --- |
| CONTRACT_REVIEW | actor 和创建人当前 ai:review/file:read、固定原 fileVersion/sha、原 stance/focus/base/LLM identity、当前 round/instructions/全部补材 snapshot/previousReport/decision；参考库和已保存 evidence 活性校验 |
| DOCUMENT_GENERATE | actor 和创建人 ai:generate/document:write/document:read；固定 documentId、source documentVersion、标题/正文/instructions/caseContext/modelRevision；只生成待复核新版本，不覆盖人工当前版本，不发布 |
| CASE_ANALYSIS | actor 和创建人 ai:review/file:read；固定 case/background/requirements、完整选定 parseTask/fileVersion/sha/text/segments、LLM identity+revision、decision |
| 解析/索引 | 沿用 requireSource/contexts/indexes.recoveryInput 和独立 TENANT 归属，不改变历史权限 |

领域服务新增只读 recoveryInput/validateRecoveryInput，允许且仅允许统一当前 DEAD/WAITING_HUMAN(DELIVERY)，不能临时改为可执行状态来调用旧 input。将固定输入构造与状态校验拆成小助手，保持原 begin/input 的执行态要求。返回内部受限输入，不公开 apiKey/原文/对象路径。

生成适配器不调用 TaskContextBiz.get 的 file_version JOIN。合同/案件即使已有原文件 context，也必须再用领域方法校验完整固定材料。行政角色不能绕过已撤权创建人的后台授权。所有费用确认均仅授权尚未执行步骤；STARTED/FAILED 被费用勾选也不能重放。

## 三工作流 AI SQL eligibility

新增内部 workflow-recovery/eligibility 端点；索引专用端点与严格 {status} 响应保持兼容。Java 新客户端可复用有界 HTTP 代码，但不要让索引输入沿用合同/生成/案件的哈希规则。

请求由 Java 从领域只读输入产生：type、taskId 和经过明确去凭据的固定输入；Node 在 SQL 前严格类型/大小/递归凭据拒绝、tenant/thread/round/source 验证。新路径单独设置合法最大输入的有界 JSON body（建议 8MiB），不把普通所有 HTTP 路径扩大到此限。当前默认 256KB，必须为新 eligibility 路径加特例。

探针仅同原执行线程 GET_LOCK(...,0)、SELECT、RELEASE_LOCK，有限数据库超时。不能 setup schema、写 lease/journal/checkpoint、调用模型/embedding/RAG、删除任何记录。即使合同使用命名空间，命名锁仍是原 tenant/thread；锁释放异常销毁连接并返回 UNAVAILABLE。

判定规则：
- BUSY：原线程锁占用，人工按钮不可恢复。
- UNCERTAIN：任一相关原日志 STARTED/未知不确定状态；不受费用勾选覆盖。旧轮日志只检查状态和类型，不重演旧轮。
- FAILED：任何原付费步骤 FAILED，拒绝原任务恢复。
- INPUT_CHANGED：当前原输入 hash、命名空间、已保存 snapshot/metadata 与 Java 固定输入不符，未知 operation key，round 越界等。
- UNAVAILABLE：库/响应/解码不可用，记录超过类型上限，必要 snapshot 缺失或无法验证；fail closed。
- SAFE：执行协议 2、当前领域授权有效、固定计算身份一致，所有已有操作均可复用。尚未开始的操作无记录，人工入口须已有显式费用确认；自动 TTL 仍只沿用原 invocation 的提交授权。

使用现有 contractIdentity / generationIdentity / analysisIdentity，不复制另一套序列化。它们均排除 attempt/sv 和 runtime Key；合同 round0 identity 保持兼容，round>0 包含 instructions/supplements/previousReport。decision 用 Java 持久决定，不伪造/清空；已有决定却缺 checkpoint 的合同/案件必须拒绝。

操作白名单：
- 合同 round0：extract-clauses-v1 / retrieve-knowledge-v1 / analyze-risk-v1 / deep-review-v1；round1..10 仅实际图中的对应 -round-n 键（补材不重新抽取原条款），每个 key 唯一。
- 生成：document-draft-v1。
- 案件：case-facts-v1 / case-disputes-v1 / case-high-risk-v1。

生成 operation.input_hash 可直接与 generationIdentity 比较。合同/案件的 operation hash 含前一节点数据，不能把整体 identity 与这些 hash 直接比较。按现有节点公式结合有界当前 checkpoint 和必要已保存 dependency result 校验；没有足够状态证明一致时返回 UNAVAILABLE，不能拼造事实/原文。当前轮读 result_blob 的范围和总字节有界，旧轮不解码正文。索引专用“不读取 result_blob”测试不应误套到需要 checkpoint 的新探针。

合同若缓存了 RAG evidence 而 Java 尚未保存 report，恢复校验不能通过新的检索请求付费。使用无费用的 Java evidence 活性校验（已有 validateEvidence 的相同 liveCitation/active-source 规则），或在无法证明活性时拒绝；不能把缓存引用当作当前仍获授权。正常发布依旧经过原 validateEvidence。

公共响应仅 {status}，不带 body/Key/source/chunks/result_blob；Java 客户端仍要求响应 <=1024 字节、完整 5 秒期限、HTTP200、严格键/重复键/尾随内容检查，并将未知或网络错误归 UNAVAILABLE。人工恢复动作事务内再次探针，不能只依赖页面此前展示的 SAFE。

## DLQ 不丢消息

新三个监听必须继续使用 taskDeadLetterContainerFactory：MANUAL、单消费者、prefetch1、forceStop、独立 listenerId。
- 业务登记事务返回后才 ACK。
- 非法/未绑定事件复制原字节到 persistent quarantine，mandatory、broker confirm、无 return 后才 ACK。
- 数据库或 outbox/ledger/audit事务失败，不 ACK、不 nack 原 DLQ（DLQ 没下一级 DLX），仅暂停并异步停止该 owned listener；通道关闭让原未确认消息保留。
- 重启必须等 stop 完成且 SELECT 1 健康，继续既有 15 秒策略；不要重启所有 Rabbit 容器。
- ACK 本身失败也暂停，不把已提交结果回滚伪装为未提交；重投靠幂等 ledger/CAS。
- classify 未知值不可降低 UNCERTAIN；相同登记重复 only monotonic kind/retry 合并。
- 日志继续不输出 payload/header/异常正文/凭据。

collector 对合同/生成当前合法旧事件可按已绑定 outbox 兼容缺 type；案件事件已有 type/schema/case，保持严格。未来新事件可统一显式 type，但不能把所有历史缺 type 都当合法，不能把生成的 documentVersion 当 fileVersion。

## 分工及实施顺序

| 工作包 | 建议负责人 | 文件/边界 |
| --- | --- | --- |
| Java 通用投递、拓扑、collector、迁移、eligibility HTTP 客户端、合同/生成适配 | root | TaskDeliveryRecoveryBiz、TaskDeadLetterCollector、RabbitMqConfig、新迁移、ContractReviewService/Repository、DocumentGenerationService/Repository；保留领域算法 |
| Node 三消费者与通用 delivery、新只读 eligibility、图非付费错误包装 | doc_finish | task-delivery.service、三个 consumer、workflow 输入/错误边界、三个 identity/eligibility validation 复用、http-body/app.module、Node 回归；不能改 runOnce 重放规则 |
| 案件 Java 适配与协议/DELIVERY guard、真实库回归 | case_analysis_finish | CaseAnalysisService/Repository 及其测试；与 root 约束迁移统一 |
| 前端处理记录与真实浏览器闭环 | ui_finish | TasksPage、TaskDeliveryRecoveryPanel、api/tasks；领域面板 DELIVERY 提示/不能误显示复核或补材；费用说明与撤权清空 |

先结束并固化当前 actual runtime 验收和清理，再作为单独阶段编辑。Maven target 串行；Node 与浏览器每阶段明确冻结的源码/dist/hash，不热替换进程已 require 的模块。UI 只依赖后端 canRecover/status，不自行推断日志安全。

最小 UI 费用规则直接复用索引模式：付费类型集合为 KNOWLEDGE_INGEST/CONTRACT_REVIEW/DOCUMENT_GENERATE/CASE_ANALYSIS，恢复 POST 必须 confirmModelCosts=true；文案“已完成步骤复用结果，尚未执行步骤可能产生费用”。不必新增动态费用预测字段。UNCERTAIN/FAILED/BUSY/INPUT_CHANGED/UNAVAILABLE 一律禁按钮；缺少勾选禁止发送。相同 UUID 网络重试、过期状态刷新、迟到401/403清空和跨任务切换防串号必须保留。

## 有意义的验收场景

1. 三类各一个真实隔离 RabbitMQ 10 秒 TTL→原队列：原始 UTF8字节/event/attempt/sv相同；另外两档60/300秒参数验证，计数3后DLQ，不等待十分钟机械重复。
2. 领取前503，领取后实际callback503、checkpoint写故障：独立进程恢复，SUCCEEDED缓存不增加对应供应商调用；成功回调丢失不改发失败。
3. 原 paid STARTED、FAILED、供应商429/5xx 被 runOnce 分类、未知状态：真实AI SQL，TTL/人工checkbox也不能触发旧模型请求，日志保持原状态。
4. Q4→R5等恢复事件（包括案件/生成）再崩溃重投；生成 Java input 的旧sv相邻领取兼容真实检查；旧attempt消息和迟到callback不覆盖新attempt。
5. 合同多补材轮同attempt：旧round原outbox死信到达新roundRUNNING，ACK但不改状态/ledger/report；当前round正确登记；namespace/operation/原thread锁不变。
6. 回调已提交但ACK丢失、重复DLQ、同UUID恢复网络重试、两个并发恢复：一个CAS winner/一个outbox，旧intent不能恢复后续dead；版本溢出拒绝。
7. 普通WT REVIEW不是投递DEAD；DELIVERY不能approve/supplement；已确认报告/decision在投递登记及恢复后完整保存，恢复仅完成既有决定且模型调用不增加。
8. 当前文件删除、材料text/sha/segments变化、基准文书版本改变可读性、模型revision变化、知识依据失活、创建人撤权、其他tenant/普通同事请求：动作前拒绝，不增加outbox和模型调用；任务仍私有。
9. 客户端/AI探针：真实本地HTTP body>256KB合法中文，超8MiB拒绝，401/错误secret/夹带Key在SQL前拒绝；数据库忙、释放锁失败、超时/超1024响应/重复键/尾随数据都fail closed，0供应商调用、0journal写入。
10. DLQ事务插入ledger/审计/outbox分别失败，原消息不ACK、不reject；仅当前owned container暂停，数据库恢复后原消息重投成功；quarantine confirm/return/timeout、ACK失败仍保留。
11. 隔离浏览器分别完成三类死信详情→费用未勾选拒绝→勾选恢复→最终业务结果；核对Java+Node+MQ+AI SQL与模型计数。至少一个纯缓存恢复为0新增调用、一个确实未开始步骤只在明确确认后调用一次。
12. 撤权期间迟到请求、跨任务切换、已终态重复消息、UNCERTAIN禁恢复页面和后端均验证。fixture仅独立tenant/vhost，精确清理DB/Redis/AI SQL/MQ/对象与审计trace，冻结进程关闭。

不将设计稿、mock消费者或队列参数检查写成完整HTTP/MQ/浏览器闭环通过；此后按实际证据更新原 docs/task-delivery-recovery.md 的范围说明。
