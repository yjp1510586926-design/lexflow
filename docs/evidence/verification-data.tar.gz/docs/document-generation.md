# AI 文书生成与复核

案件详情 → 案件文书 → 编辑已保存文书 → **AI 起草**。填写生成要求，并逐次确认模型调用可能产生费用；未保存的编辑不能提交。结果页和任务记录只查询状态，不会自行重新调用模型。生成要求改变后需要重新勾选费用确认。

生成基于提交时保存的正文版本、案件背景和模型配置版本。结果作为独立 `AI_DRAFT / PENDING_REVIEW` 版本入库，不覆盖生成期间保存的人工版本，也不自动发布。可在版本历史查看完整正文，复核通过后切换当前版本并回到草稿状态；复核通过不代表文书已发布。未复核或已驳回的 AI 版本不能直接恢复为当前版本，发布和导出也检查复核状态。

## 配置与权限

使用管理员手动保存的 LLM 配置。NestJS 设置 `LEXFLOW_AI_ALLOWED_HOSTS` 精确主机白名单，服务端运行时取得 Key；页面、outbox 和 AI checkpoint 不保存 Key。文书生成最多接受 3 万字源正文、2000 字要求，返回正文最多 3 万字、10 项待补信息；单次模型输出最多 6000 token，60 秒超时，SDK 自动重试关闭。

提交及执行需要当前有效账号、律所成员资格、未归档案件的编辑资格，以及 `ai:generate`、`document:write`、`document:read`、`task:read`。结果遵守任务创建者/管理员范围并复查案件与文书读取权限；取消还需要 `task:cancel`。管理员也必须持有所需权限。执行、模型返回和版本写入前重新授权；撤权、归档或配置替换后，旧执行不能发布结果。

V18 增加 `DOCUMENT_GENERATE` 任务、`document_generation` 及 `ai:generate` 权限，授予现有 `TENANT_ADMIN` / `LAWYER` 角色；权限仍可按律所调整。

## 接口与状态

所有公共接口使用当前会话、CSRF、租户隔离及统一请求追踪。

| 接口 | 行为 |
|---|---|
| `POST /api/v1/cases/{caseId}/documents/{documentId}/generations` | 提交 `sourceVersionId`、`instructions`、`idempotencyKey`、`confirmModelCost=true`；返回 HTTP 202 与 `taskId/status/stateVersion`。同键同输入返回原任务，不同输入 409；新提交必须使用当前保存版本。 |
| `GET /api/v1/tasks/{id}/generation` | 返回源版本、生成要求、任务状态、待补信息和可读结果版本。成功后仍保留实际复核状态。 |
| `POST /api/v1/tasks/{id}/generation/recover` | 提交 `stateVersion`，仅允许排队/执行中任务重新投递，保持原 attempt；重新授权并复用已有执行结果。 |
| `POST /api/v1/tasks/{id}/cancel` | 使用现有取消入口，排队、执行中或调用不确定任务立即进入取消终态；迟到结果不能入库。 |
| `POST /api/v1/cases/{caseId}/documents/{documentId}/versions/{versionId}/review` | 使用现有人工复核入口；通过后明确切换当前版本。 |

事务同时写任务、不可变输入记录和 `document.generate.requested.v1` outbox。RabbitMQ 队列 `lexflow.q.document.generate` 由 NestJS 消费；专用内部 `/internal/v1/document-generations/{id}/input`、`begin`、`result` 受内部认证保护。泛用任务回调不能伪造文书结果。

正常状态为 `QUEUED → RUNNING → SUCCEEDED`。失败为 `FAILED`，取消为 `CANCELLED`。独立 AI MySQL 保存租户绑定线程、checkpoint、执行锁及 `document-draft-v1` 外部操作记录；重复投递或恢复复用已保存结果，同一任务只保存一份 AI 版本。回调网络失败进入 DLQ，人工恢复仍读取缓存，不自动重发模型请求。

外部操作已开始、结果是否完成无法确定时进入 `WAITING_HUMAN`。页面提示不会自动重发；需要先取消，再由用户明确决定是否新建生成任务。SDK 超时/明确错误也不会自动重试。该流程不提供通用解析/索引的延迟重试或完整死信管理，后者仍是独立待办。

## 实际验证与限制

2026-10-02 Java 全量 146 项通过（service 32、api-core 114），其中新增七项真实本机基础设施测试；Node 60 项中 59 通过、1 项可选真实 Milvus 跳过；React 类型检查与生产构建通过。修复已有人工复核中的乐观锁版本重复递增问题，验证通过后实际切换版本。Node 消费队列选择和健康能力的最后配置变更另经编译与实际启动验证。

专用租户 900000180 的浏览器/HTTP/RabbitMQ/独立 AI MySQL 链路验证两个任务：1585 取消且不调用模型；1586 生成独立 v3，保留生成期间人工保存的 v2，拒绝直接恢复未复核结果，查看正文、复核切换与同步 TXT 下载成功，121 字节正文与结果一致。NestJS 重启后重复投递两条消息，没有新增模型调用或版本；撤权返回 403，清空旧正文/任务按钮，观察至少六秒没有新读取。八张截图已查看。

本次仅调用本机 HTTPS 合成模型一次，真实供应商调用为零，不能证明法律质量或真实供应商兼容性。为保护其他开发任务，关闭定时调度，只将本次专用 outbox 投递到真实 RabbitMQ 并确认；定时 publisher 沿用全量回归证据。任务中心与新生成结果完成浏览器验收，TXT 使用已存在同步接口核对字节，没有重跑异步导出全链路。

测试租户、两项任务、三份版本、四个 checkpoint 和一条外部操作记录已清理，未创建 MinIO 对象；仅按本次日志捕获的精确追踪号清理独立提交审计。专用 Java/NestJS/Vite/HTTPS 服务及浏览器已关闭，端口复核释放。初始 401/favicon 404、预期恢复 409/撤权 403、注销后 401 留在观察记录；初次验收脚本的提示文本、结果字段和多按钮定位已据实际页面修正，没有重复提交。

证据：[检查摘要](evidence/generation-checks.json)、[浏览器结果](evidence/generation-browser-result.json)、[消费后持久状态](evidence/generation-owned-state.json)、[界面清理](evidence/generation-cleanup.json)、[测试审计清理](evidence/generation-test-cleanup.json)。项目其他需求仍见 [需求核查](需求实现核查-2026-10-01.md)。
