# 空数据安装验收

2026-10-09 在当前 macOS 主机上完成新空数据实例验收。复用已运行的 6 个本地开发基础容器，使用新的随机业务数据库、独立 AI 数据库和账号、RabbitMQ vhost、MinIO bucket 及 Spring Session Redis namespace。Java、Node、React 分别使用 8097、3017、5187，浏览器会话独立。本验收没有验证另一操作系统或一台全新机器；当前主机已具备 JDK 21、Maven、Node.js 24 和项目依赖。

## 实际步骤与结果

按 [README](../README.md)、[管理员初始化](administrator-setup.md) 和 [AI 服务说明](../ai-service/README.md) 执行。相关专项已有通过记录，本轮只运行一次 `mvn -DskipTests package`，将可执行 jar 复制到专用临时目录后启动，未重复全套测试。新业务库与新 AI 库在首次服务启动前均查询确认 0 表。

首次以 `bootstrap` profile 启动 Java，从空库成功执行全部 23 个 Flyway 迁移；创建唯一律所和唯一管理员，并创建 TENANT_ADMIN、LAWYER、READER 三个初始角色。密码与部署密钥均随机生成，临时文件权限为 0600，未作为命令参数或日志输出。

停止首次初始化进程后，不携带 bootstrap profile 或管理员初始化环境变量，以普通方式启动。真实 HTTP 获得 CSRF、登录管理员、读取唯一成员，从 0 案件创建并读回合成案件；浏览器通过登录表单登录，显示空案件列表，再刷新显示新案件及案件详情。

停止普通进程，使用不同的律所名、用户名和密码再次以 bootstrap 启动。该进程退出码为 1，明确报错“已有律所数据，不允许重新初始化”。之后再次普通启动，原密码仍能登录，现有律所、用户、角色、成员、权限、安装标记、案件及文书表的数据指纹完全一致，仍为 1 个律所、1 个用户和 1 个案件。原浏览器会话在 Java 重启后仍可读取案件。

AI 初始化使用 `AI_WORKFLOW_MYSQL_DATABASE`、`AI_WORKFLOW_MYSQL_USER` 和私有密码调用 `infra/mysql/init-ai-workflow.sh`，然后在冻结的独立 AI 目录运行 `npm run setup:workflow`，创建 4 张工作流表。按原生 `npm start` 启动，健康接口返回 UP；低权限 AI 账号读取本轮 Java 业务库被拒绝，未授权包接口返回 401，空模型域名白名单的配置测试返回 400。未配置任何模型，任务表和工作流记录均为 0，没有真实供应商请求或费用。

安装过程中发现 AI 数据库名和初始化脚本原先固定默认库名。主任务已修复为允许安全的独立 `lexflow_ai_…` 库名及短账号，并保留 root/Java 账号拒绝规则；本验收实际使用修复后的脚本和源代码。配置专项另有 3/3 通过记录，本轮未重复运行。

## 范围与清理

Spring Session 的随机 namespace 已在实际 Redis key 中确认。登录频率限制仍使用共享的 `lexflow:login:ip:127.0.0.1`：本轮正常登录可能增加该计数，清理不删除它。因此不能把本轮描述为与共享 Redis 的全部计数完全隔离。

浏览器已退出并关闭，自有 Java、Node、Vite 和一次性回环登录辅助进程已停止。精确删除本轮两个随机数据库、两个数据库账号、空 bucket、vhost 及自己的 Redis namespace；业务库中的本轮请求审计随专用库删除。临时密码、密钥和环境文件已删除，原数据卷未删除或重建，6 个基础容器保留并保持健康。

机器证据见 [检查记录](evidence/fresh-install-checks.json)、[验证摘要与日志哈希](evidence/fresh-install-validation.txt) 和 [清理记录](evidence/fresh-install-cleanup.json)。页面证据见 [空案件列表](evidence/fresh-install-empty-browser.png)、[新案件列表](evidence/fresh-install-case-browser.png)、[案件详情](evidence/fresh-install-case-detail-browser.png)。检查记录绑定可执行 jar、冻结 AI 源码、安装说明、原始日志、DOM 快照与截图的 SHA-256；日志校验未发现本轮生成的凭据。
