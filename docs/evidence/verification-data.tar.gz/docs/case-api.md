# 案件接口约定

所有接口使用服务端会话中的租户标识，写入操作必须附带 CSRF token。

## 列表

`GET /api/v1/cases?page=1&size=20&keyword=&status=&type=&ownerId=`

可选过滤字段应在未选择时省略，不发送空 status。关键词匹配标题或案件编号，百分号及下划线按普通字符处理。状态、类型、负责人和关键词组合生效；只统计调用者可访问的案件。

响应 `data`：`{items: CaseView[], total: number, page: number, size: number}`。ID 均使用字符串，版本号为整数。最大每页 100 条。

## 案件成员

- `GET /api/v1/cases/{id}/members`：成员列表。
- `POST /api/v1/cases/{id}/members`：`{userId,role}`，role 为 EDITOR 或 READER。
- `PATCH /api/v1/cases/{id}/members/{userId}`：`{role}`，调整非负责人角色。
- `DELETE /api/v1/cases/{id}/members/{userId}`：移除非负责人。
- `POST /api/v1/cases/{id}/owner`：`{userId,version}`，原子转交负责人。

转交时校验目标为本律所有效用户，原负责人保留 EDITOR 成员资格，新负责人设为 OWNER；案件版本递增，旧版本提交返回 409。归档案件禁止修改成员和转交，需先按权限恢复。

案例状态遵循 DRAFT → ACTIVE → ARCHIVED，授权负责人或律所管理员可以将 ARCHIVED 恢复为 ACTIVE。

## 案件日期

创建请求可带 `filedOn: "2026-09-15"`；详情和列表返回 `filedOn`、`archivedAt`。更新请求中省略 `filedOn` 保留旧值，显式 `null` 清空，非空值必须为有效的 `YYYY-MM-DD` 日期。日期改动沿用案件版本校验。归档时间由服务端生成，恢复办理时清空，客户端不能自行指定。

## 证据目录

- `GET /api/v1/cases/{caseId}/evidence?page=1&size=20`：目录分页，返回 `items/total/page/size/canEdit`，顺序相同按目录 ID 排列。
- `GET /api/v1/cases/{caseId}/evidence/{fileVersionId}`：读取某原件版本的目录，尚未记录返回 `data: null`。
- `PUT /api/v1/cases/{caseId}/evidence/{fileVersionId}`：`{version,source,collectedAt,description,sortOrder}`；创建用 version 0，更新使用读取到的目录版本，重复创建或冲突返回 409。

原件须属于当前租户和案件且可用。来源必填，最多 500 字；说明可为空字符串，最多 4000 字；顺序为 0–100000。收集时间可为空，非空须带时区，例如 `2026-09-20T09:30:00+08:00`，服务端以 UTC 保存/返回并支持历史日期。目录不会替换原件或改变其摘要。

读取要求 `file:read` 及案件读取权；保存还要求 `file:upload` 和案件编辑权。归档与只读成员不能编辑，失败或已删除的原件不出现在目录。原件下载沿用私有文件接口及其授权检查。
