# 空数据安装验收

2026-10-09 在当前 macOS 主机上完成新空数据实例验收。复用已运行的 6 个本地开发基础容器，使用新的随机业务数据库、独立 AI 数据库和账号、RabbitMQ vhost、MinIO bucket 及 Spring Session Redis namespace。Java、Node、React 分别使用 8097、3017、5187，浏览器会话独立。本验收没有验证另一操作系统或一台全新机器；当前主机已具备 JDK 21、Maven、Node.js 24 和项目依赖。

## 实际步骤与结果

按 [README](../README.md)、[管理员初始化](administrator-setup.md) 和 [AI 服务说明](../ai-service/README.md) 执行。相关专项已有通过记录，本轮只运行一次 `mvn -DskipTests package`，将可执行 jar 复制到专用临时目录后启动，未重复全套测试。新业务库与新 AI 库在首次服务启动前均查询确认 0 表。

首次以 `bootstrap` profile 启动 Java，从空库成功执行全部 23 个 Flyway 迁移；创建唯一律所和唯一管理员，并创建 TENANT_ADMIN、LAWYER、READER 三个初始角色。密码与部署密钥均随机生成，临时文件权限为 0600，未作为命令参数或日志输出。

停止首次初始化进程后，不携带 bootstrap profile 或管理员初始化环境变量，以普通方式启动。真实 HTTP 获得 CSRF、登录管理员、读取唯一成员，从 0 案件创建并读回合成案件；浏览器通过登录表单登录，显示空案件列表，再刷新显示新案件及案件详情。

停止普通进程，使用不同的律所名、用户名和密码再次以 bootstrap 启动。该进程退出码为 1，明确报错“已有律所数据，不允许重新初始化”。之后再次普通启动，原密码仍能登录，现有律所、用户、角色、成员、权限、安装标记、案件及文书表的数据指纹完全一致，仍为 1 个律所、1 个用户和 1 个案件。原浏览器会话在 Java 重启后仍可读取案件。

AI 初始化使用 `AI_WORKFLOW_MYSQL_DATABASE`、`AI_WORKFLOW_MYSQL_USER` 和私有密码调用 `infra/mysql/init-ai-workflow.sh`，然后在冻结的独立 AI 目录运行 `npm run setup:workflow`，创建 4 张工作流表。按原生 `npm start` 启动，健康接口返回 UP；低权限 AI 账号读取本轮 Java 业务库被拒绝，未授权包接口返回 401，空模型域名白名单的配置测试返回 400。未配置任何模型，任务表和工作流记录均为 0，没有真实供应商请求或费用。

安装过程中发现 AI 数据库名和初始化脚本原先固定默认库名。主任务已修复为允许安全的独立 `lexflow_ai_…` 库名及短账号，并保留 root/Java 账号拒绝规则；本验收实际使用修复后的脚本和源代码。配置专项另有 3/3 通过记录，本轮未重复运行。

## 范围与清理

Spring Session 的随机 namespace 已在实际 Redis key 中确认。登录频率限制仍使用共享的 `lexflow:login:ip:127.0.0.1`：本轮正常登录可能增加该计数，清理不删除它。因此不能把本轮描述为与共享 Redis 的全部计数完全隔离。

浏览器已退出并关闭，自有 Java、Node、Vite 和一次性回环登录辅助进程已停止。精确删除本轮两个随机数据库、两个数据库账号、空 bucket、vhost 及自己的 Redis namespace；业务库中的本轮请求审计随专用库删除。临时密码、密钥和环境文件已删除，原数据卷未删除或重建，6 个基础容器保留并保持健康。

机器证据见 [检查记录](evidence/fresh-install-checks.json)、[验证摘要与日志哈希](evidence/fresh-install-validation.txt) 和 [清理记录](evidence/fresh-install-cleanup.json)。页面证据见 [空案件列表](evidence/fresh-install-empty-browser.png)、[新案件列表](evidence/fresh-install-case-browser.png)、[案件详情](evidence/fresh-install-case-detail-browser.png)。检查记录绑定可执行 jar、冻结 AI 源码、安装说明、原始日志、DOM 快照与截图的 SHA-256；日志校验未发现本轮生成的凭据。

## 2026-10-09 新基础设施 MVP 验收（V28）

以下是独立于上述 V23 历史记录的新一轮验收。仍使用当前 macOS 主机已安装的 JDK、Maven、Node.js 和 Docker，以新 Compose 项目 `lexflow-fresh-c1234ef7b754` 创建独立网络及六个新数据卷，没有复用旧基础容器或数据。首次创建前确认本项目容器、网络、卷均不存在；首次运行后确认业务库零表、Redis 零 key、RabbitMQ 零队列、MinIO 零 bucket，Milvus 无 collection。

Java 从空业务库执行 V1～V28，初始化一个律所及管理员，停止 bootstrap 进程后以普通配置运行。AI 使用独立低权限数据库及账号完成四张工作流表初始化；其账号读取 Java 业务库被拒绝。六个新基础服务实际健康，Java、Node、React 使用 8117、3037、5197。此轮应用进程运行于主机，完整应用 Docker Compose 的验收另行记录，不能以此替代镜像部署证明。

### 核心业务实测

浏览器直接操作本轮真实 React 页面与 Java API，没有拦截或替换业务响应。创建合成案件和律师账号后，完成以下闭环：

- 上传 315 字节 TXT 到真实 MinIO，回读的 SHA-256 与上传文件相同。提交 `DOCUMENT_PARSE`，通过实际 Outbox、RabbitMQ 和 Node 解析成功，数据库持久化原文及来源指纹，页面可查看原文。
- 创建人工文书并保存 v1、v2、v3 历史；v3 发布后，`EXPORT` 异步任务成功。浏览器下载的 213 字节 TXT 与发布版本内容及指纹相同。前两版正文相同，记录没有把它们描述为不同内容。
- 案件未加入的律师读取返回 403、案件列表为空。管理员在实际成员页面添加为 EDITOR 后，律师可读取案件、成员、文件和文书；改为 READER 后仍可读取，修改案件返回 403，案件版本没有递增。确认移除后页面只剩 OWNER，数据库对应成员消失，四个业务读取入口均返回 403。
- 成员添加、角色修改、移除各产生一条 `SUCCESS` 业务审计，前后角色与数据库状态一致。删除时浏览器驱动在确认框处提前返回，没有保留该次 DELETE 的 HTTP 响应；删除结果由成功审计、数据库、页面和撤权后的实际 403 共同证明。
- 非创建者读取管理员的解析、导出任务始终返回 403，符合 `TaskService#get` 的创建者或律所管理员策略。案件成员资格没有扩大为查看其他人的任务。
- 未配置 LLM 时，AI 文书请求明确返回 409，提示管理员配置 API Key；没有产生生成任务或模型调用。此轮没有保存真实供应商 Key，也没有使用模拟模型结果冒充真实模型验收。

初次解析曾因本轮 Node 启动环境变量误写而进入 `DEAD/PERMANENT`；修正 `INTERNAL_SECRET` 后，在真实任务页面显式恢复并成功完成。该问题属于验收启动配置，不是解析源代码缺陷。安装时另发现成员查询使用不存在的 `cm.joined_at`，实际页面返回 500；源代码改为 `ORDER BY u.id`，通过 [真实 MySQL 成员回归](evidence/mvp-member-regression-checks.json) 后重新打包，当前页面返回 200，之后成员操作与权限检查均成功。

### 重启、构建边界与清理

业务闭环前半段使用 jar SHA-256 `0f0ffe998026593bf8c9d5bae7976feaf22a993a775cca18bdde75f81d6ffbd5`。修复成员查询后使用 jar `4631069eefe9220ba553f76b26dd09e3d4ebf7ce1d55b7e80d8dc011fbeb9695`，停止确认为本轮所有的 Java 和 Node 进程，以普通配置重启。Flyway 校验 28 个迁移且没有重复迁移；案件、成员、文件、文书、三个历史版本、两个核心任务、解析结果、导出结果八组 UTF-8 数据快照及四张 AI 工作流表计数逐项一致。管理员原浏览器会话仍能访问；重新下载同一源文件及原任务 #2 的导出文件，字节与重启前完全一致。指纹对比在成员添加、角色修改、移除之前完成，后续权限操作分别记录。

本轮证明了当前主机上的新基础设施、真实核心数据与对象、进程重启持久化及成员权限。它没有证明另一操作系统或全新机器安装，也没有证明真实 LLM / Embedding 的生成质量。AI 工作流操作数为零，真实模型调用数和费用调用数均为零。Node 域名白名单为 `api.deepseek.com`，仅准备后续已选择的供应商配置。47 条机器记录包含失败再修复的观察，不能汇总为“47 项全部通过”；浏览器累计控制台错误包含未配置/拒绝响应、旧成员 SQL 500 及主动重启时的短暂服务不可达，不能写成零错误。

完成后关闭独立浏览器，核对命令与目录后停止本轮 Java、Node、React 进程；核对 UUID、Compose 标签及非 external 资源后，仅删除本轮七个容器（含一次性卷初始化容器）、六个数据卷及一个网络。专属资源剩余均为零，十一项端口检查全部空闲，私有运行目录及状态文件已删除。旧开发环境六个容器保持原 ID 且健康，没有删除其数据卷。清理库存检查曾误输出本轮一次性 Compose 凭据，记录明确保留该操作失误；对应数据库、消息及对象存储账号随专属基础设施删除而失效，保留的验收日志已脱密扫描。这里没有声称完成浏览器退出登录。

证据见 [新基础设施检查记录](evidence/fresh-mvp-checks.json)、[精确清理记录](evidence/fresh-mvp-cleanup.json)及 [重启前](evidence/fresh-mvp-runtime/core-before-restart-utf8.json) / [重启后](evidence/fresh-mvp-runtime/core-after-restart-utf8.json)数据快照。新增 [重启后导出页面](evidence/fresh-mvp-export-restart-browser.png)、[只读成员](evidence/fresh-mvp-members-reader-browser.png)、[移除后成员页面](evidence/fresh-mvp-members-revoked-browser.png)已目视检查。检查记录绑定冻结 Node/React 文件、两份 jar、当前成员 Mapper、日志、数据库快照及截图的指纹，保留每次操作的状态与追踪 ID。
