# 废弃向量物理回收

Java 立即以有效源文件、知识库和当前 `index_version` 控制检索与引用；后台回收只删除已经失去发布资格的精确向量位置。它不调用 Embedding 或 LLM，不删除 Collection，也不删除整个律所或知识库。

## 登记与发布

V26 增加 `knowledge_vector_artifact`，记录租户、CASE/TENANT 范围、知识库、文档、文件版本、索引版本、任务、Collection、模型标识和维度。记录不含正文、向量或 API Key。

新的 Node 索引执行在每个 upsert 批次前调用 Java 内部登记接口。Java 锁定当前任务及文档，复查 attempt、stateVersion、创建者权限、固定材料和模型配置，再登记精确位置；登记失败时该批次不会写入 Milvus。已经持久化的模型批次继续按原有工作流恢复规则复用。

Java 接受成功回调时在同一发布事务内补登记，兼容升级前的执行服务。V26 从现有文档的明确 Collection、模型和维度导入已知发布位置。历史失败或取消任务没有持久化其实际 Collection/维度，无法由迁移准确定位；这部分不能猜测删除，应由运维取得精确位置后单独审阅处理。

## 退役与清理

启用原有 `scheduling.enabled` 后，每轮最多检查 10 个位置。检查保留仍有有效来源的当前发布版本，以及该文档当前可恢复的 QUEUED、RUNNING 或 WAITING_HUMAN 在途版本。失败或取消的影子版本、成功替换后的旧版本，以及源删除、源校验失败或知识库停用后的失效位置进入退役。

退役和审计写入在同一 MySQL 事务内提交，随后才调用 Node 的私密回收接口。删除表达式由服务端结构化构造，始终同时限制 tenant、case、knowledgeBase、document、fileVersion 和 indexVersion。Collection 必须与登记的模型摘要及维度一致；无效位置不能扩展范围。

每次物理删除使用独立短期 lease；过期或失败重试不会复用另一次 lease 的完成结果。失败采用有界退避。清理成功后记录仍然保留，并每日重新清理同一精确位置，覆盖旧执行进程在第一次删除后才完成的迟到 upsert。退役位置不能被后续登记重新启用。清理时也复查精确有效发布指针，防止当前可见版本被删除。

只有内部 shared secret 可以访问 `/internal/v1/knowledge-vectors/retire`。返回、超时或服务不可用无法确认成功时，Java 保留墓碑和重试资格；不把未知结果标为已清理。

## 验证

2026-10-09 在独立随机空 schema 实际应用 V1→V28，使用真实 MySQL 事务、私密 Node HTTP 和真实 Milvus 的完整回收场景通过。验证了取消、成功替换、源删除、失败、迟到写入重扫、范围隔离、审计写入失败回滚及旧 lease 完成拒绝；没有真实模型调用。测试 Collection、schema、临时账号和私有 Node 服务均已清理。

Node 索引与回收选定检查 9 项通过，另一个旧真实 Milvus 用例未启用；相关消费者及恢复检查 16 项通过，两个旧真实 AI SQL 用例未启用。未启用项没有被计为通过。每日墓碑复查通过将测试自己的记录设置为到期来验证，没有等待完整 24 小时，也没有做生产负载测试。

验证明细、源文件摘要及清理证据见 [回收证据](evidence/knowledge-vector-retirement-checks.json)。
