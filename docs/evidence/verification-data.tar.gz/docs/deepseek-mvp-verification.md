# DeepSeek MVP 接入与验收

2026-10-09，用户指定 DeepSeek，并明确授权最多 5 次调用、总费用上限 0.05 美元，仅发送合成材料且不自动重试。本轮实际使用 `deepseek-flash` 调用 4 次，连接测试、文书起草、合同审查及页面人工确认均已通过；API 与 AI 容器重建后，结果和配置保持一致。这是当前学习型 MVP 的真实业务验收，不代表完整 v1.1 需求或法律质量基准全部完成。

当前结论以 [真实业务记录](evidence/deepseek-mvp-real-checks.json)、[供应商调用账本](evidence/deepseek-mvp-provider-ledger.jsonl) 和 [实际浏览器记录](evidence/deepseek-mvp-browser-checks.json) 为准。此前 [协议与配置检查](evidence/deepseek-mvp-checks.json) 保留目录读取、合成响应测试和未授权预检的历史范围。

## 已核实

- 官方 `GET https://api.deepseek.com/models` 返回 HTTP 200，实际模型编号为 `deepseek-flash`、`deepseek-v4-pro`。这是模型目录读取，未提交生成请求。
- 独立容器的合成律所已通过实际应用保存 DeepSeek LLM 配置：PUT、GET 均为 HTTP 200，公开响应不含 Key 或密文。实际 MySQL 值为 AES-256-GCM 密文，主代理在私有内存中解密比对相同；没有输出明文或密文，也没有调用供应商。API单独重建及整套保卷重建后，密文和配置版本保持一致；主代理另行复验公开配置200、版本不变且脱敏。验收脚本此前两次使用旧 CSRF 绑定得到403，修正脚本后保存成功，不把拒绝算作成功或产品缺陷。
- LLM 接入沿用 LangChain `ChatOpenAI`，基础地址为 `https://api.deepseek.com`。官方支持 OpenAI 格式与 JSON 对象输出，见 [接入文档](https://api-docs.deepseek.com/en/) 和 [JSON 输出](https://api-docs.deepseek.com/guides/json_mode/)。
- 官方默认启用思考模式。本项目对精确官方域名显式关闭思考，避免短连接探测的输出预算被思考占用，见 [思考参数](https://api-docs.deepseek.com/guides/thinking_mode/)。此设置保留现有 JSON 结构、来源校验、超时与零自动重试。
- `npm run build` 成功；`node --test test/legal-question.test.cjs test/configuration-test.test.cjs` 共 10 项通过、0 项失败、2 项可选真实 MySQL 集成检查跳过。本次新增检查实际 SDK 序列化后的请求地址、专有参数、32 token、JSON 格式与禁止重定向；响应由合成 fetch 提供，属于协议检查。
- 付费前，当前镜像的真实 SDK 与费用护栏完成禁网预检，退出0：使用测试凭据，实际序列化符合32 token/JSON/关闭思考/禁止重定向契约；缺少授权时请求被拒绝，独立探针账本为空、权限0600，临时容器已删除。此预检本身没有真实调用，不能代替后续真实业务证据。
- 实际调用使用同一镜像与 [费用护栏](evidence/deepseek-mvp-record-provider.cjs)，出站前限制5次、合计20,000输入预留和11,432输出、0.05美元预算；请求意图先落盘，未知结果停止后续调用，已有账本拒绝重启清零。正式账本为4次意图和4次HTTP200结果，没有自动重试或失败后补调。

## 最小真实业务验收

验收使用独立容器、合成律所及真实 Java → RabbitMQ → NestJS → DeepSeek → MySQL 流程，没有 Mock 业务 API 或合成供应商响应。凭据仅由主代理操作，应用按律所加密保存，没有写入源码、Compose、日志或公开证据。

- 连接测试：HTTP200，记录1为 `SUCCEEDED`；相同请求标识重放和读取结果不新增调用。此项只验证接口可用。
- 文书起草：任务3实际成功，保存独立 AI 草稿v2及4项待补信息，原手工v1在复核前仍为当前版本。实际页面复核HTTP200后，v2为 `APPROVED` 并成为当前版本；文书仍是 `DRAFT`，没有自动发布。
- 合同审查：真实上传558字节合成合同，任务4的报告原文与文件摘要相符，8条引用全部对应原文精确位置。没有知识库证据，页面明确提示需要人工补充法律资料。页面人工确认HTTP200后为 `SUCCEEDED / stateVersion5`，决定标识和中文批注真实持久化，报告未被批准操作改写。
- 幂等：生成与合同的相同标识、相同正文返回原任务；改变正文均409；合同相同决定重放200并保留原决定。重启后再次验证这些路径，正式调用仍为4次。

API、AI 容器均实际更换身份，相同镜像与原数据卷保持。重启阶段撤去付费授权，费用护栏使用独立空探针账本，原正式账本保持不变。16张业务表与4张AI工作流表使用UTC、显式 `utf8mb4`、逐字段 `HEX(CAST(... AS BINARY))` 和NULL标记按主键排序比较，20张表前后摘要全部相同。工作流持久化有3个thread、12个checkpoint、22个write、4个成功operation，没有失败或不确定operation。重启后文书、合同及脱敏配置真实GET均200，探针账本0字节。

本轮解决的验收脚本问题已单列，不算产品通过项：过期会话需重新登录、运行时没有FormData改为实际multipart字节、SQL客户端未指定UTF8造成中文显示失真，以及对决定动作DTO字段的错误断言。浏览器确认已成功后的截图定位超时也保留为已解决脚本问题，没有重复点击批准。

实际供应商usage合计输入1,311、输出960、总计2,271 token。执行前复核 [官方价格](https://api-docs.deepseek.com/quick_start/pricing/)；将全部输入按峰时未命中缓存0.30美元/百万token、输出按1.20美元/百万token计算，保守估算为 **0.00154530美元**。非峰时或缓存命中可更低；此数是usage估算，没有对账供应商账单。账本保守预留为0.013613美元，未超过授权总额。

## 范围

本次 MVP 不展开12组真实质量基准、模型横向比较、补充材料多轮合同审查或生产恢复演练。Embedding/Rerank仍未配置，知识索引与RAG真实模型验收不在本轮通过范围；不能用DeepSeek对话模型冒充向量模型，不能返回假向量或假答案。

旧部署阶段的11张表快照比较同一未显式指定UTF8客户端的TSV输出，单靠它不能证明Unicode字段存储字节一致；原文件/导出实际字节及ASCII密文、版本证据仍有效。本轮独立20表HEX检查补强当前AI业务重启持久化，未改写旧日志。

配置方式见 [AI 凭据](ai-credentials.md)，独立部署步骤见 [MVP 部署](mvp-deployment.md)。临时验收实例的最终清理状态记录在真实业务JSON中；验收数据不应被当作可长期使用的正式业务环境。
