# 文书并发编辑与冲突处理

保存正文、恢复历史版本、发布文书都必须提交读取文书时取得的 `expectedVersion` 和 `expectedCurrentVersionId`。前者是文书记录的并发版本，后者是当前正文版本 ID；不能用历史版本的 `versionNo` 替代。缺少任一令牌返回 HTTP 400，任一令牌过期返回 HTTP 409。

| 操作 | 请求内容 | 成功后的结果 |
| --- | --- | --- |
| `POST /api/v1/cases/{caseId}/documents/{documentId}/versions` | `content` 和两个预期令牌 | 新建人工版本，切换当前正文，文书并发版本加一，状态为草稿。 |
| `POST /api/v1/cases/{caseId}/documents/{documentId}/restore/{fromVersionId}` | 两个预期令牌 | 复制指定历史正文为新人工版本，保留所有旧版本，文书并发版本加一，状态为草稿。 |
| `POST /api/v1/cases/{caseId}/documents/{documentId}/publish` | 两个预期令牌 | 发布当前已保存正文，文书并发版本加一，不新建正文版本。 |

服务在案件授权与行锁后读取当前文书，再比较两个预期令牌。冲突请求不能追加正文、切换当前指针或改变发布状态。正文编号使用锁定的当前读取，包含事务旧快照建立后已提交的人工版本和待审 AI 草稿；独立 AI 草稿追加到版本历史，保留人工编辑的当前指针。

页面遇到冲突时保留未保存正文，读取并展示服务器最新正文，暂时禁止保存、恢复和发布。用户对照两份内容进行合并，再点击“我已对照合并，继续编辑”采用最新令牌；合并正文仍需要单独保存。待审或驳回的 AI 草稿不能通过恢复、发布或导出绕过人工复核。

2026-10-09 本地验收通过：6 项服务单元测试、9 项真实 MySQL 并发、时间与 HTTP 测试、60 项现有集成测试，共 75 项；前端构建通过。两个独立事务分别覆盖“人工编辑旧快照之后追加 AI 草稿”和“AI 草稿旧快照之后人工保存”，并验证唯一版本编号、当前指针保留和同任务重复保存幂等。

真实浏览器连接本地 HTTP 服务，未拦截 API 响应：另一个编辑器保存 v2 后，浏览器的过期 v1 提交得到 409，数据库仍只有两个正文版本；浏览器保留本地编辑并展示 v2，显式合并后以最新令牌保存 v3，随后实际发布并恢复 v1 为新 v4。合成租户、会话和 HTTP 审计记录已精确清理，独立 Java、Vite 和浏览器已关闭，没有真实模型请求。

文书及版本接口的 `createdAt` 统一为带 `Z` 的 ISO UTC 时间，表示数据库中同一个时间点；页面的文书列表与版本历史都显示北京时间。修复前，列表使用 JVM 本地 `Timestamp.toString()`，版本历史使用裸 UTC `LocalDateTime`，造成 8 小时差异。真实数据库微秒时间与 HTTP 输出一致性回归已通过，页面两处现在都显示 `2026-10-09 02:24:25`。旧快照没有时区的字符串保留原数字并标注“未标注时区”，不会被浏览器误解为本地时间后再次偏移。

当前源码、75 项检查、真实时间显示及清理证据见 [最新验收记录](evidence/document-timezone-checks.json)；最新截图：[文书列表时间](evidence/document-timezone-list-browser.png)、[版本历史时间](evidence/document-timezone-history-browser.png)。旧无时区快照的兼容分支使用一条合成拦截响应验证，见 [旧格式展示](evidence/document-timezone-legacy-browser.png)，不视为真实旧后端 E2E。

先前并发闭环的 [历史验收记录](evidence/document-concurrency-checks.json) 及截图仍保留：[冲突保留编辑](evidence/document-concurrency-conflict-browser.png)、[合并保存](evidence/document-concurrency-merged-browser.png)、[恢复为新版本](evidence/document-concurrency-restored-browser.png)。这些截图拍摄于时间显示修复前。上述记录只证明文书范围，不代表整个项目需求已全部验收。
