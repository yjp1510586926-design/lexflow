# AI 凭据配置与实现状态

产品入口为“设置 → AI 配置”，由律所管理员手动填写本律所自己的服务商、模型、地址和 Key。普通成员不需要填写，也无权查看 Key。保存配置不触发模型调用，不使用内置公共 Key。

## 部署主密钥

Java 环境变量 `LEXFLOW_AI_MASTER_KEY` 接收 Base64 编码的 32 字节随机密钥，用于加密用户提供的 API Key。它与模型 API Key 是两种不同凭据。主密钥由部署者保管，不提交代码、不回显到前端；多个实例必须使用一致的主密钥。

未设置时普通业务可启动，AI 凭据保存不可用。不得配置默认公共主密钥。丢失或替换主密钥后，旧凭据将无法解密；轮换必须先设计迁移流程，不能直接覆盖环境变量后声称轮换完成。

## 当前已实现

`AiCredentialCipher` 使用 AES-256-GCM、随机 12 字节 nonce 与 128 位认证标签；认证上下文包含租户 ID、用途（LLM / EMBEDDING / RERANK）和格式版本。解密错误不携带凭据内容或底层异常。

测试覆盖加解密、随机密文、跨租户/用途拒绝、篡改拒绝、错误主密钥拒绝、未配置主密钥以及非法主密钥。

## 执行与验收边界

按租户取用凭据、主动连接测试和模型调用已接入 Java → NestJS。管理员保存配置不会联网；连接测试和 AI 业务均须用户主动提交。供应商请求禁止重定向、SDK 自动重试，出站域名须列入 `LEXFLOW_AI_ALLOWED_HOSTS`。外部操作结果使用独立 AI 工作流数据库保存；成功结果复用，遗留不确定请求不自动重发。没有实现供应商账户充值或统一账单系统。

已有接口、MySQL、工作流、浏览器检查证明配置权限与调用协议；其中历史合成模型结果不能证明真实供应商能力或业务质量。2026-10-09 用户明确授权最多5次调用、合计0.05美元；实际DeepSeek调用4次完成连接、文书起草与合同审查，页面人工确认成功。应用配置保存与脱敏回读均200，MySQL密文在私有内存中解密比对通过；API/AI实际重建后，20表HEX摘要一致，结果与配置可读取且没有新增调用。具体证据、usage估算及限制见 [DeepSeek MVP 验收](deepseek-mvp-verification.md)。


## 配置 API

- `GET /api/v1/settings/ai`：管理员读取本律所用途、服务商、地址、模型和更新时间，以及 `storageReady`；不返回 Key 或密文。
- `PUT /api/v1/settings/ai/{purpose}`：用途为 LLM / EMBEDDING / RERANK，JSON 字段 provider、baseUrl、model、apiKey。替换配置需要重新输入 Key；保存不联网。
- `DELETE /api/v1/settings/ai/{purpose}`：删除本律所对应配置。

V6 迁移增加 ai_configuration 表，按 tenant_id + purpose 唯一。Controller → Biz（授权与事务审计）→ Service（校验及加密）→ Mapper。服务地址只接受不含账号、查询参数与片段的 HTTPS URL；NestJS 仅允许部署者指定的精确域名并禁止重定向。域名白名单由部署者控制；不应加入可由普通用户控制的主机。保存接口本身不执行网络请求。


## 设置页面

侧栏“AI 配置”可选择对话、向量、排序三种用途，填写服务商、HTTPS 地址、模型和只写 API Key。服务未配置主密钥时禁用保存；接口错误明确展示；替换需要重新输入 Key，提交后清空输入，删除需页面确认。不写入浏览器持久存储。主动连接测试使用少量合成文本并须逐次确认费用；读取、刷新和重复读取结果不会重新调用模型。成功只表示当前配置的接口兼容性，不表示法律分析正确。

## DeepSeek 的最小配置

在部署环境设置 `LEXFLOW_AI_ALLOWED_HOSTS=api.deepseek.com`，并生成独立 `LEXFLOW_AI_MASTER_KEY`。管理员在页面选择 LLM，填写服务商 `DeepSeek`、基础地址 `https://api.deepseek.com`、模型 `deepseek-flash` 与自己的 Key。Key 不放在 React 构建参数、Compose 示例或源码中。

本项目对官方 DeepSeek 域名使用 `thinking: {type: "disabled"}`，保留 JSON 对象输出和已有 token/超时上限；其他兼容服务不带这一专有参数。当前官方模型目录提供对话模型，不能以该 Key/对话模型冒充已配置的 Embedding 或 Rerank。合同审查和 AI 文书起草可只用 LLM；知识索引与 RAG 问答还须单独配置支持向量接口的模型。
