# 文件对象清理

删除 API 在数据库事务内把文件标为 DELETED，同时将全部已登记版本的对象键写入 `file_cleanup_job`。下载立即不可见；API 不等待对象存储删除。

后台每 10 秒执行有上限的批次，一批最多 10 个对象。使用 `FOR UPDATE SKIP LOCKED` 领取一个到期任务，仅允许清理对应文件状态为 DELETED、FAILED 或已到期 UPLOADING 的对象。

成功记录 DONE 和完成时间；存储失败保留 PENDING，记录异常类别（不存原始异常消息），增加 attempts，按指数退避重试，间隔最高一小时。进程崩溃会释放事务锁，重启后继续领取。删除成功但数据库提交失败时可能再次删除同一对象，MinIO 删除不存在对象具有幂等性。

`SCHEDULING_ENABLED=false` 可以关闭该定时消费者。任务记录不会丢失，恢复调度后继续处理。业务数据库的任务记录是清理状态的依据，不能以日志输出代替。

2026-10-09新增可配置记录压缩及永久对象墓碑；默认不压缩。只有已完成且超过配置期限、源文件已删除/失败的记录才可压缩，墓碑继续每日复查迟到上传。异步TXT结果到期机制也已接入，历史结果默认无期限。详细行为及独立验证见[导出期限与清理记录维护](object-lifecycle.md)。

运维查询（仅在有权的开发数据库）：

```sql
SELECT id, tenant_id, file_id, status, attempts, last_error,
       next_attempt_at, completed_at
FROM file_cleanup_job
WHERE status = 'PENDING'
ORDER BY next_attempt_at, id;
```

当前管理界面尚未展示清理任务。

上传开始时，在独立短事务中保存文件、版本和一小时后到期的清理任务，再执行 MinIO 上传。成功确认会移除该补偿任务；失败在另一个事务中标为 FAILED 并立即安排清理。进程中断时初始任务仍存在，到期后将 UPLOADING 标为 FAILED 并清理。

上传确认再次校验案件权限和状态，只允许从 UPLOADING 转为 AVAILABLE。若期间发生删除、权限撤销或超时清理，确认失败会重新安排对象清理，防止迟到上传重新发布文件。文件服务的上传编排不加入调用方数据库事务，不能依赖外层事务回滚它；测试必须显式清理已提交数据。
