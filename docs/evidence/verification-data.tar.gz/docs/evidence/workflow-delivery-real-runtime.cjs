const fs=require('node:fs'),http=require('node:http'),path=require('node:path');
const stateFile=process.env.LEXFLOW_DELIVERY_STATE;
const read=()=>JSON.parse(fs.readFileSync(stateFile,'utf8'));
const record=(kind,data)=>{const s=read();fs.appendFileSync(path.join(s.dir,'runtime-events.jsonl'),JSON.stringify({at:new Date().toISOString(),kind,...data})+'\n',{mode:0o600});};
const models=require('./node-dist/ai/legal-question.js');
models.configuredQuestionModel=(input)=>{
 if(input.tenantId!=='1'||input.baseUrl!=='https://delivery-synthetic.example.test/v1'||input.model!=='delivery-synthetic')throw Error('Synthetic isolated configuration required');
 const type=input.documentId?'DOCUMENT_GENERATE':input.sources?'CASE_ANALYSIS':'CONTRACT_REVIEW';
 return {invoke:async messages=>{const state=read(),mode=state.control?.taskModes?.[input.taskId]??state.control?.typeModes?.[type]??'none';const data=JSON.parse(messages[1].content);let result,stage;
 if(type==='DOCUMENT_GENERATE'){stage='draft';result={content:'甲方应依据材料中的付款条款履行义务。【待补充：收款账户】',missingInformation:['收款账户']};}
 else if(type==='CASE_ANALYSIS' && data.sources){stage='facts';const source=data.sources[0],segment=source.segments[0],quote=source.text.slice(segment.startOffset,Math.min(segment.endOffset,segment.startOffset+18));result={facts:[{statement:'材料记载双方有付款约定。',citationIds:['C1']}],pendingVerification:[],citations:[{id:'C1',parseTaskId:source.parseTaskId,index:segment.index,quote}]};}
 else if(type==='CASE_ANALYSIS'){stage='disputes';result={issues:[{title:'付款履行情况',level:'LOW',analysis:'需要结合履行凭证核对。',suggestion:'收集实际付款证明。',citationIds:['C1']}],missingMaterials:[],insufficientEvidence:true,recommendationBoundary:'仅为材料整理，须由办案律师核对。'};}
 else if(data.text){stage='clauses';result={contractType:'合成付款协议',clauses:[{id:'1',title:'付款',quote:'验收后付款。'}]};}
 else {stage='risk';result={risks:[{clauseId:'1',level:'LOW',reason:'付款时间需核对。',suggestion:'核对验收及支付凭证。',evidenceIds:[]}],missingMaterials:[],insufficientEvidence:true,basisConflicts:[]};}
 record('model',{taskId:input.taskId,type,stage,mode,synthetic:true});
 if(mode==='started')return await new Promise(()=>{});
 if(mode==='failed')throw Object.assign(new Error('Synthetic paid 429'),{response:{status:429}});
 return {content:JSON.stringify(result)};
 }};
};
const proxy=http.createServer((req,res)=>{const state=read(),match=req.url.match(/\/tasks\/(\d+)\/source|\/(?:contract-reviews|case-analyses|document-generations)\/(\d+)\/result/),id=match?.[1]??match?.[2],mode=id?(state.control?.taskModes?.[id]??state.control?.typeModes?.[{contract:'CONTRACT_REVIEW',case:'CASE_ANALYSIS',document:'DOCUMENT_GENERATE'}[req.url.split('/')[3]?.split('-')[0]]]):'none';
 if((match?.[1]&&mode==='unpaid')||(match?.[2]&&['callback','failed'].includes(mode))){record('http503',{taskId:id,route:match?.[1]?'source':'result'});res.writeHead(503,{'Content-Type':'application/json'});res.end('{"error":"synthetic-local-delivery-failure"}');req.resume();return;}
 const target=http.request({hostname:'127.0.0.1',port:8097,path:req.url,method:req.method,headers:req.headers},upstream=>{res.writeHead(upstream.statusCode,upstream.headers);upstream.pipe(res);if(match)record('httpForward',{taskId:id,route:match?.[1]?'source':'result',status:upstream.statusCode});});target.on('error',()=>{res.writeHead(503);res.end();});req.pipe(target);
});
proxy.listen(8098,'127.0.0.1',()=>{process.env.JAVA_CORE_URL='http://127.0.0.1:8098';require('./node-dist/main.js');});
