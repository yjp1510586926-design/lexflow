from pathlib import Path
import sys,json,subprocess,hashlib,os
p=Path(__file__).parent;s=json.loads((p/'state.json').read_text());mode=sys.argv[1]
name=s['project']+'-mysql-1';meta=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
assert meta['Config']['Labels']['com.docker.compose.project']==s['project'] and meta['State']['Running']
tables={'case_info':'id','case_member':'tenant_id,case_id,user_id','file_object':'id','file_version':'id','document':'id','document_version':'id','async_task':'id','task_parse_result':'tenant_id,task_id','document_export_job':'tenant_id,task_id','document_export_artifact':'token','ai_configuration':'tenant_id,purpose'}
rows={}
for table,order in tables.items():
 sql=f"SET time_zone='+00:00';USE lexflow;SELECT COUNT(*) FROM {table};SELECT * FROM {table} ORDER BY {order};"
 r=subprocess.run(['docker','exec','-i',name,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql --protocol=TCP --host=127.0.0.1 -uroot -N -B'],input=sql.encode(),capture_output=True)
 if r.returncode:raise RuntimeError('snapshot failed for '+table+' exit '+str(r.returncode))
 count,raw=r.stdout.split(b'\n',1);rows[table]={'count':int(count),'sha256':hashlib.sha256(raw).hexdigest()}
assert rows['case_info']['count']==1 and rows['case_member']['count']==2 and rows['document']['count']==1 and rows['ai_configuration']['count']==1
if mode=='before':
 s['persistenceBaseline']=rows
else:
 baseline=s['persistenceBaseline'];assert rows==baseline,'business persistence snapshot differs'
 s['checks'].append({'id':'database-exact-domain-persistence-'+mode,'passed':True,'all11DomainTablesExact':True,'rowCounts':{k:v['count'] for k,v in rows.items()},'encryptedAiConfigurationAndRevisionExact':True})
(p/'state.json').write_text(json.dumps(s,ensure_ascii=False));os.chmod(p/'state.json',0o600)
print(json.dumps({'snapshot':mode,'rowCounts':{k:v['count'] for k,v in rows.items()},'matched':mode!='before','noCiphertextPrinted':True}))
