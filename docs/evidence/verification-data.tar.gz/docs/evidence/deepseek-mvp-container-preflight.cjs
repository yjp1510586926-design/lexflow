'use strict';
// Offline acceptance setup only: no real credential and no supplier permission.
const fs = require('node:fs');
const requireApp = require('node:module').createRequire('/app/package.json');
const { configuredQuestionModel } = require('/app/dist/ai/legal-question.js');
const { SystemMessage, HumanMessage } = requireApp('@langchain/core/messages');
const guardedFetch = globalThis.fetch;
let observed = null;
let interceptionCount = 0;
globalThis.fetch = async (address, options) => {
  const url = new URL(typeof address === 'string' ? address : address.url);
  if (url.hostname === 'api.deepseek.com') {
    interceptionCount++;
    const body = JSON.parse(options.body);
    observed = {
      origin: url.origin, pathname: url.pathname, method: options.method,
      redirect: options.redirect, model: body.model,
      outputLimit: body.max_tokens ?? body.max_completion_tokens,
      format: body.response_format?.type, thinking: body.thinking?.type,
      nonStreaming: body.stream !== true,
      stringMessages: body.messages.every(message => typeof message.content === 'string'),
    };
  }
  return guardedFetch(address, options);
};
(async () => {
  const model = configuredQuestionModel({
    provider: 'DeepSeek', baseUrl: 'https://api.deepseek.com',
    model: 'deepseek-flash', apiKey: 'offline-fixture-not-a-provider-key',
  }, 'api.deepseek.com', { maxTokens: 32, timeout: 2000 });
  let rejectedWithoutPermission = false;
  try {
    await model.invoke([
      new SystemMessage('Only emit JSON {"ok":true}.'),
      new HumanMessage('Synthetic offline acceptance check.'),
    ], { response_format: { type: 'json_object' } });
  } catch (error) {
    for (let cause = error, depth = 0; cause && depth < 10; cause = cause.cause, depth++)
      if (String(cause.message).includes('MVP provider fee authorization absent')) rejectedWithoutPermission = true;
  }
  const ledger = fs.statSync(process.env.LEXFLOW_DEEPSEEK_MVP_LEDGER);
  const passed = rejectedWithoutPermission && interceptionCount === 1 && ledger.size === 0
    && (ledger.mode & 0o777) === 0o600
    && observed?.origin === 'https://api.deepseek.com'
    && observed?.pathname === '/chat/completions' && observed?.method === 'POST'
    && observed?.redirect === 'error' && observed?.model === 'deepseek-flash'
    && observed?.outputLimit === 32 && observed?.format === 'json_object'
    && observed?.thinking === 'disabled' && observed?.nonStreaming && observed?.stringMessages;
  console.log(JSON.stringify({
    passed, networkMode: 'none', realCredentialUsed: false,
    feeAuthorizationPresent: !!process.env.LEXFLOW_DEEPSEEK_MVP_AUTHORIZATION,
    rejectedWithoutPermission, sdkInterceptions: interceptionCount,
    ledgerBytes: ledger.size, ledgerMode: (ledger.mode & 0o777).toString(8),
    serializedRequest: observed, paidCalls: 0,
  }));
  if (!passed) process.exitCode = 1;
})().catch(() => { console.log(JSON.stringify({passed: false, paidCalls: 0})); process.exitCode = 1; });
