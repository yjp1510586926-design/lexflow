# MVP 单机部署

本流程部署同一套真实 React、Java 与 NestJS 应用，业务数据写入 MySQL，登录会话保存在 Redis，文件和导出结果进入私有 MinIO，异步任务使用 RabbitMQ。Web 的 Nginx 将 `/api/` 转到 Java，与页面保持同源。Java、NestJS、数据库、消息队列和对象存储没有宿主机公开端口；内部 `/internal/` 不经过 Web 代理。

基础闭环包含登录、案件和成员、文件上传与解析、人工文书版本及异步 TXT 导出。AI 功能使用管理员在应用中保存的模型配置；没有配置时明确报错，不返回模拟结果。知识索引和资料问答还需要真实 Embedding 配置及可选 `vector` profile。此流程不包含生产备份平台、通知服务或全量模型基准评估。

## 全新安装

宿主机需要 Docker Engine / Docker Desktop、Docker Compose v2 和 OpenSSL。镜像构建分别使用 JDK 21、Node.js 24；宿主机无需另装 Java、Node 或 Maven。默认入口仅监听 `127.0.0.1:8088`。基础服务的内存上限合计约 3.9 GiB；启用 Milvus/etcd 后约 6.2 GiB，构建时需另留内存和磁盘空间。

从仓库根目录开始。生成器只创建不存在的文件，权限为 `0600`，不会覆盖已有配置：

```sh
sh deploy/configure-mvp.sh
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml config --quiet
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml build api
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml build ai-service
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml build web
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml up -d --wait mysql redis rabbitmq minio
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml run --rm workflow-setup
```

`.env.mvp.local` 已由项目忽略规则排除，保留随机基础设施密码、服务间凭据和 AI 配置加密主密钥。它不含模型 API Key。工作流账号 `lexflow_ai` 只获得独立 `lexflow_ai` 库权限，无法读取 Java 业务库。MySQL 首次空卷启动创建账号；`workflow-setup` 明确执行幂等的工作流建表步骤。已有 MySQL 数据卷不会重新执行首次脚本，修改配置文件也不会自动修改其中的账号密码。

首次管理员使用现有 `bootstrap` 入口，只能初始化空业务库。以下交互输入适用于 Bash 和 Zsh；密码不写入命令参数：

```sh
export LEXFLOW_TENANT_NAME='演示律所'
export LEXFLOW_ADMIN_USERNAME='admin'
printf '管理员初始密码（至少12字符，最多72个UTF-8字节）：'
read -r -s LEXFLOW_ADMIN_PASSWORD
printf '\n'
export LEXFLOW_ADMIN_PASSWORD
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml run --rm --no-deps \
  -e LEXFLOW_TENANT_NAME -e LEXFLOW_ADMIN_USERNAME -e LEXFLOW_ADMIN_PASSWORD \
  api --spring.profiles.active=bootstrap
```

看到“首次初始化完成，律所 ID=…”后记下律所 ID，再按 `Ctrl+C` 停止该初始化容器。初始化命令会保持 Java 进程在线，不把进程启动当成初始化完成；重复初始化会拒绝已有业务数据。随后普通启动：

```sh
unset LEXFLOW_ADMIN_PASSWORD
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml up -d --wait
curl --fail http://127.0.0.1:8088/api/health
```

打开 `http://127.0.0.1:8088`，用刚才的律所 ID、用户名和密码登录。`/healthz` 只表示 Web 在线；`/api/health` 表示 Java 可响应；NestJS 内部健康表示进程与消费者启动完成，均不代表外部模型已经可用。验证业务时应实际创建案件、上传 TXT、等待解析任务成功、保存文书并发起 TXT 导出，再下载核对正文。

## AI 配置与向量能力

部署默认白名单为 `api.deepseek.com`，与已选 DeepSeek 供应商一致。管理员进入应用设置保存 LLM 配置，API Key 经 Java 主密钥加密后按律所持久化，不放进 Compose、React 或镜像。保存与查看配置不会调用模型；连接测试和实际 AI 任务必须由用户主动确认费用后触发。模型名称与当前官方可用模型及应用兼容说明保持一致。

Embedding 是独立用途，不能把 LLM 模型名称直接当作 Embedding。需要知识检索时，先选好真实向量供应商和模型，把其准确域名加入 `LEXFLOW_AI_ALLOWED_HOSTS`，再启动已有向量服务：

```sh
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml --profile vector up -d --wait
```

修改白名单后需重新创建 `ai-service` 容器。单独解析文件与文书 TXT 导出不需要向量模型、Milvus 或模型费用。合同审查、AI 起草和案件分析需要 LLM；选择知识库作为参考时还需要已授权、已发布的真实索引。

## 运行、升级与停止

查看状态和运行日志：

```sh
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml ps
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml logs --tail 100 api ai-service web
```

服务使用具名数据卷，正常重启、镜像重建和 `down` 保留数据。Java 启动时 Flyway 校验并执行新增迁移，不能修改已执行的迁移文件。升级前保存配置与现有数据，完成必要备份后按前述命令重新构建镜像，再 `up -d --wait`。AI 主密钥必须保持不变，否则已有模型配置无法解密。导出期限与详细清理记录归档默认均为 `0`，按已有业务策略明确决定后再启用。

```sh
docker compose --env-file .env.mvp.local -f docker-compose.mvp.yml down
```

若通过远程主机部署，可先保持 loopback 入口并通过 SSH 转发访问。面向外部用户时将 Web 接在已有 HTTPS 反代后，并设置 `COOKIE_SECURE=true`；项目不自动申请域名或证书。需要改变端口或绑定地址时修改私有配置中的 `WEB_PORT` 和 `WEB_BIND_ADDRESS`，再重新创建 Web 容器。

本地开发仍可使用原 `docker-compose.dev.yml`。手动为独立项目补建工作流账号时，`infra/mysql/init-ai-workflow.sh` 支持 `LEXFLOW_COMPOSE_FILE`、`LEXFLOW_COMPOSE_ENV_FILE` 与 `LEXFLOW_COMPOSE_PROJECT_NAME`，默认保持原开发项目行为；必须准确指向要初始化的本地项目，不覆盖已有账号密码。

## 当前验证边界

2026-10-09：独立单机容器部署验收已通过，结果记录在 [mvp-deployment-checks.json](evidence/mvp-deployment-checks.json)。真实构建的 Java、NestJS、React/Nginx 镜像完成首次管理员初始化和同源登录；真实页面创建案件、上传 TXT、经 RabbitMQ/NestJS 提取原文、保存人工文书版本、提交异步 TXT 导出并实际下载。上传原文 112 字节、导出正文 136 字节均与输入逐字节一致。只读成员能够查阅授权案件和版本，携带有效 CSRF 的文书写入及机构管理请求实际返回 403，业务库没有新增文书。

单独重建 Java 时，额外占用旧 IP 使其地址确实更换，原 Web 容器保持不变，同源健康和业务请求恢复为 200。随后整套 `down` / `up -d --wait` 完成：7 个常驻容器身份全部更换且健康，工作流建表容器退出 0，5 个具名卷保留；11 张业务域表前后内容完全一致，包括模型配置密文与版本。重新加载真实页面后 Redis 会话仍有效，案件、成员、文件、文书、解析结果和脱敏配置的 7 个业务读取均为 200，MinIO 原文件和导出文件的下载字节保持一致。

首次尝试暴露的实际部署问题已经修复：MySQL 健康检查使用 TCP，避免首次初始化的临时 socket 被误认作服务就绪；Nginx 使用 Docker 动态 DNS，支持 Java 容器地址变化；Java 五处内部服务客户端统一允许精确的 `ai-service` HTTP 地址及原有本机 HTTP/HTTPS 地址，外部模型配置仍要求 HTTPS。内部地址及既有配置探测、恢复协议的 27 项选定 JUnit 检查均通过；镜像构建跳过测试，测试结果由独立执行提供，不能据此声称全库测试通过。JSON 中的记录还包含准备观察及已经修复的历史失败，记录条数不等于通过测试数。

本次使用合成业务数据及真实基础设施，没有 Mock API，也没有真实模型调用或模型费用。DeepSeek 配置已在真实应用中加密持久化并通过重建后脱敏回读，此结果不证明 LLM 业务已经完成真实模型验收。只读成员仍可看见部分成员管理按钮，后端会拒绝无权操作；按钮呈现尚未优化。可选向量 profile、本机之外的新操作系统、公网 HTTPS 和生产恢复演练均不在本次部署证明范围。原开发环境的 6 个容器身份均保留，最终仅 5 个健康，原 Milvus 处于退出状态；不将它描述为当前全部健康，也不据此推断退出原因。验收实例暂保留在 `http://127.0.0.1:8089`，供继续检查核心流程。
