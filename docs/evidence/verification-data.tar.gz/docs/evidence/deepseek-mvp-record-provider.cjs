'use strict';
// Local acceptance recorder only. It does not replace the SDK or provider endpoint.
const fs = require('node:fs');
const ledger = process.env.LEXFLOW_DEEPSEEK_MVP_LEDGER;
if (!ledger || !ledger.startsWith('/tmp/lexflow-deepseek-mvp-')) throw new Error('MVP recorder requires its private ledger');
const descriptor = fs.openSync(ledger, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL, 0o600);
const state = { calls: 0, inputBound: 0, outputBound: 0, reservedMicrosUSD: 0, halted: false };
const originalFetch = globalThis.fetch;
const record = value => { fs.writeSync(descriptor, JSON.stringify(value) + '\n'); fs.fsyncSync(descriptor); };
globalThis.fetch = async (address, options) => {
  if (new URL(typeof address === 'string' || address instanceof URL ? address : address.url).hostname !== 'api.deepseek.com')
    return originalFetch(address, options);
  if (process.env.LEXFLOW_DEEPSEEK_MVP_AUTHORIZATION !== 'approved-0.05-usd') throw new Error('MVP provider fee authorization absent');
  const url = new URL(typeof address === 'string' || address instanceof URL ? address : address.url);
  const body = JSON.parse(options?.body);
  if (url.origin !== 'https://api.deepseek.com' || url.pathname !== '/chat/completions' || url.search || url.hash
      || options?.method?.toUpperCase() !== 'POST' || options.redirect !== 'error' || body.model !== 'deepseek-flash'
      || body.stream === true || body.tools || body.functions || body.response_format?.type !== 'json_object'
      || body.thinking?.type !== 'disabled' || !Array.isArray(body.messages) || !body.messages.length
      || body.messages.some(message => typeof message.content !== 'string' || !['system', 'user', 'assistant'].includes(message.role)))
    throw new Error('MVP provider request out of scope');
  const output = body.max_tokens ?? body.max_completion_tokens;
  // UTF-8 bytes plus deliberately generous per-message protocol overhead bound tokens.
  const input = body.messages.reduce((sum, message) => sum + Buffer.byteLength(message.content) + 128, 128);
  const reserve = Math.ceil(input * 0.3 + output * 1.2);
  if (!Number.isSafeInteger(output) || output < 1 || output > 6000 || state.halted || state.calls >= 5
      || state.inputBound + input > 20000 || state.outputBound + output > 11432
      || state.reservedMicrosUSD + reserve > 50000) throw new Error('MVP provider call or fee limit reached');
  state.calls++; state.inputBound += input; state.outputBound += output; state.reservedMicrosUSD += reserve;
  const sequence = state.calls;
  record({ kind: 'INTENT', sequence, model: body.model, inputTokenUpperBound: input, outputTokenUpperBound: output,
    cumulativeReservedMicrosUSD: state.reservedMicrosUSD, time: new Date().toISOString() });
  try {
    const response = await originalFetch(address, options);
    const result = await response.clone().json();
    const usage = result.usage;
    const validUsage = response.ok && Number.isSafeInteger(usage?.prompt_tokens) && usage.prompt_tokens >= 0
      && Number.isSafeInteger(usage?.completion_tokens) && usage.completion_tokens >= 0
      && usage.total_tokens === usage.prompt_tokens + usage.completion_tokens;
    if (!validUsage || usage.prompt_tokens > input || usage.completion_tokens > output) state.halted = true;
    record({ kind: 'RESULT', sequence, status: response.status, usage: validUsage ? {
      inputTokens: usage.prompt_tokens, outputTokens: usage.completion_tokens, totalTokens: usage.total_tokens } : null,
      halted: state.halted, time: new Date().toISOString(), billingVerified: false });
    return response;
  } catch {
    state.halted = true;
    record({ kind: 'UNKNOWN', sequence, halted: true, time: new Date().toISOString(), billingVerified: false });
    throw new Error('MVP provider result uncertain');
  }
};
